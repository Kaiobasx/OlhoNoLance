package com.example.backEnd;


public @interface SpringBootApplication {

}
