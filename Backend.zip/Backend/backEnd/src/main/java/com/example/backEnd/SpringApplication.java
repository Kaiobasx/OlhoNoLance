package com.example.backEnd;


public class SpringApplication {

    public static void run(Class<BackEndApplication> class1, String[] args) {
        
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

}
