package com.example.repository;



import com.example.model.Lance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LanceRepository extends JpaRepository<Lance, Long> {
}
